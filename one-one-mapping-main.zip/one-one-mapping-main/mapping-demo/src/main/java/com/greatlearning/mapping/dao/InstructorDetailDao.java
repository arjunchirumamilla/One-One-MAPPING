package com.greatlearning.mapping.dao;

public class InstructorDetailDao {

}
